"""
Fake Job Posting Detection
A reproducible machine-learning project using TF-IDF and Logistic Regression.

Expected dataset: a CSV file with a target column named "fraudulent".
Common EMSCAD columns include title, company_profile, description,
requirements, benefits, telecommuting, has_company_logo, and has_questions.

Usage:
    python fake_job_classifier.py --data data/fake_job_postings.csv
    python fake_job_classifier.py --data fake_job_postings.csv --target fraudulent
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import make_column_selector


TEXT_CANDIDATES = [
    "title", "company_profile", "description", "requirements", "benefits"
]
NUMERIC_CANDIDATES = [
    "telecommuting", "has_company_logo", "has_questions"
]
CATEGORICAL_CANDIDATES = [
    "employment_type", "required_experience", "required_education",
    "industry", "function", "location"
]


def clean_text(value: object) -> str:
    """Normalize text while preserving useful words and numbers."""
    if pd.isna(value):
        return ""
    text = str(value).lower()
    text = re.sub(r"https?://\S+|www\.\S+", " URL ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def load_dataset(path: Path, target: str) -> pd.DataFrame:
    """Read CSV and validate the target column."""
    df = pd.read_csv(path)
    df.columns = [str(c).strip().lower() for c in df.columns]
    target = target.lower()

    if target not in df.columns:
        raise ValueError(
            f"Target column '{target}' not found. Available columns: "
            + ", ".join(df.columns)
        )

    df = df.drop_duplicates().copy()
    df = df.dropna(subset=[target]).copy()

    # Standard EMSCAD target values are 0 = legitimate, 1 = fraudulent.
    # Convert common textual labels when present.
    if df[target].dtype == "object":
        labels = df[target].astype(str).str.strip().str.lower()
        mapping = {
            "real": 0, "legitimate": 0, "genuine": 0, "false": 0, "0": 0,
            "fake": 1, "fraud": 1, "fraudulent": 1, "scam": 1, "true": 1, "1": 1,
        }
        mapped = labels.map(mapping)
        if mapped.isna().any():
            raise ValueError(
                f"Could not map every target label in '{target}'. "
                "Use 0 for legitimate and 1 for fraudulent, or update the mapping."
            )
        df[target] = mapped.astype(int)
    else:
        df[target] = pd.to_numeric(df[target], errors="coerce")
        df = df.dropna(subset=[target]).copy()
        if not set(df[target].unique()).issubset({0, 1}):
            raise ValueError("This example expects a binary target encoded as 0 and 1.")
        df[target] = df[target].astype(int)

    if df[target].nunique() != 2:
        raise ValueError("The target column must contain both classes: 0 and 1.")

    return df


def prepare_features(df: pd.DataFrame, target: str) -> tuple[pd.DataFrame, list[str], list[str], list[str]]:
    """Create a compact feature table from columns that exist in the dataset."""
    available_text = [c for c in TEXT_CANDIDATES if c in df.columns]
    available_num = [c for c in NUMERIC_CANDIDATES if c in df.columns]
    available_cat = [c for c in CATEGORICAL_CANDIDATES if c in df.columns]

    if not available_text:
        raise ValueError(
            "No expected text columns found. Expected one or more of: "
            + ", ".join(TEXT_CANDIDATES)
        )

    features = df[available_text + available_num + available_cat].copy()

    # Combine the available text fields into one text feature.
    for col in available_text:
        features[col] = features[col].map(clean_text)
    features["combined_text"] = features[available_text].agg(" ".join, axis=1).str.strip()
    features = features.drop(columns=available_text)

    for col in available_num:
        features[col] = pd.to_numeric(features[col], errors="coerce")
    for col in available_cat:
        features[col] = features[col].fillna("Unknown").astype(str)

    # Remove empty text records to avoid training on no information.
    nonempty = features["combined_text"].str.len() > 0
    features = features.loc[nonempty].copy()
    labels = df.loc[features.index, target].astype(int)

    return features, labels, available_num, available_cat


def build_model(numeric_cols: list[str], categorical_cols: list[str]) -> Pipeline:
    """Build a leakage-safe preprocessing and classification pipeline."""
    transformers = [
        (
            "text",
            TfidfVectorizer(
                max_features=50000,
                ngram_range=(1, 2),
                min_df=2,
                sublinear_tf=True,
                stop_words="english",
            ),
            "combined_text",
        )
    ]

    if numeric_cols:
        numeric_pipeline = Pipeline(
            steps=[
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler(with_mean=False)),
            ]
        )
        transformers.append(("numeric", numeric_pipeline, numeric_cols))

    if categorical_cols:
        categorical_pipeline = Pipeline(
            steps=[
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore")),
            ]
        )
        transformers.append(("categorical", categorical_pipeline, categorical_cols))

    preprocess = ColumnTransformer(transformers=transformers, remainder="drop")
    return Pipeline(
        steps=[
            ("preprocess", preprocess),
            ("classifier", LogisticRegression(
                max_iter=1000,
                class_weight="balanced",
                random_state=42,
            )),
        ]
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Classify potentially fraudulent job postings.")
    parser.add_argument("--data", required=True, help="Path to the input CSV file.")
    parser.add_argument("--target", default="fraudulent", help="Target column (default: fraudulent).")
    parser.add_argument("--output", default="outputs", help="Directory for charts and metrics.")
    args = parser.parse_args()

    data_path = Path(args.data)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    df = load_dataset(data_path, args.target)
    print(f"Loaded {len(df):,} rows and {len(df.columns):,} columns.")
    print("\nTarget distribution (0=legitimate, 1=fraudulent):")
    print(df[args.target.lower()].value_counts().sort_index())

    # Save a target-distribution chart.
    plt.figure(figsize=(6, 4))
    sns.countplot(data=df, x=args.target.lower())
    plt.title("Job Posting Class Distribution")
    plt.xlabel("Class (0 = legitimate, 1 = fraudulent)")
    plt.ylabel("Number of postings")
    plt.tight_layout()
    plt.savefig(output_dir / "class_distribution.png", dpi=150)
    plt.close()

    X, y, numeric_cols, categorical_cols = prepare_features(df, args.target.lower())
    if y.value_counts().min() < 2:
        raise ValueError("At least two examples of each class are needed for a stratified split.")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model = build_model(numeric_cols, categorical_cols)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    metrics = {
        "accuracy": accuracy_score(y_test, predictions),
        "precision_fraud": precision_score(y_test, predictions, zero_division=0),
        "recall_fraud": recall_score(y_test, predictions, zero_division=0),
        "f1_fraud": f1_score(y_test, predictions, zero_division=0),
    }

    print("\nEvaluation on held-out test set:")
    for name, value in metrics.items():
        print(f"{name}: {value:.4f}")

    report = classification_report(
        y_test, predictions, target_names=["Legitimate (0)", "Fraudulent (1)"],
        zero_division=0
    )
    print("\nClassification report:\n")
    print(report)

    (output_dir / "metrics.txt").write_text(
        "Evaluation on held-out test set\n"
        + "\n".join(f"{k}: {v:.4f}" for k, v in metrics.items())
        + "\n\nClassification report:\n"
        + report,
        encoding="utf-8",
    )

    cm = confusion_matrix(y_test, predictions, labels=[0, 1])
    disp = ConfusionMatrixDisplay(
        confusion_matrix=cm,
        display_labels=["Legitimate", "Fraudulent"],
    )
    disp.plot(cmap="Blues", values_format="d")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    plt.savefig(output_dir / "confusion_matrix.png", dpi=150)
    plt.close()

    print(f"\nCharts and metrics saved in: {output_dir.resolve()}")
    print("\nReminder: predictions are indicators, not proof that a job is fraudulent.")


if __name__ == "__main__":
    main()
