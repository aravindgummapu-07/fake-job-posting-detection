# Fake Job Posting Detection Using Machine Learning

## Project overview
This project demonstrates a machine-learning workflow for classifying job postings as legitimate or potentially fraudulent. It includes data validation, text cleaning, TF-IDF feature extraction, logistic regression, and evaluation.

> **Important:** A model prediction is only a risk indicator. It cannot prove that a job is fraudulent. Verify employers and vacancies independently.

## Dataset
Use a permitted copy of the Employment Scam Aegean Dataset (EMSCAD), commonly available through Kaggle by searching for **Fake Job Postings**. The dataset should contain a target column called `fraudulent`, where `0` means legitimate and `1` means fraudulent. Do not upload a dataset unless its license permits redistribution.

## Tools
- Python
- Pandas and NumPy
- Scikit-learn
- Matplotlib and Seaborn

## Project workflow
1. Load and validate the CSV file.
2. Remove duplicate records and rows without target labels.
3. Normalize job-ad text and combine available text fields.
4. Convert text to TF-IDF features and encode structured fields.
5. Train a Logistic Regression classifier.
6. Evaluate the held-out test set with accuracy, precision, recall, F1 score, and a confusion matrix.

## Setup
Install Python 3.10 or newer, then run:

```bash
pip install -r requirements.txt
```

## Run
Place your CSV in a folder named `data/`, then run:

```bash
python fake_job_classifier.py --data data/fake_job_postings.csv
```

If your file is named differently, replace the path. If the target column has a different name, use `--target your_column_name`.

The script writes charts and metrics into an `outputs/` directory.

## Repository files
- `fake_job_classifier.py` — end-to-end training and evaluation script
- `requirements.txt` — Python dependencies
- `notebooks/` — add your exploratory notebook here
- `outputs/` — generated charts and evaluation metrics (created when the script runs)

## My contribution
For the original college team project, document your own verified contribution here. For example, if accurate: **I contributed to data cleaning and preparation as part of a five-member team.**

## Limitations and responsible use
- Results depend on dataset quality, class balance, and whether the data represents current job postings.
- Avoid treating model predictions as definitive accusations.
- Never include personal or confidential data in a public repository.
- Report actual evaluation results only after running the code on your dataset.
